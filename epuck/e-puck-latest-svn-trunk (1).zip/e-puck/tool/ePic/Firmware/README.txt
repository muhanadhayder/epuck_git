The hex file contains a BTcom firmware that is compatible with the current ePic.
