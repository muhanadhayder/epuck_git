ePic - readme.txt


To run ePic :

1) Open Matlab
2) Select ePic directory as the current Matlab directory
3) lunch ePic by running the command "main" in Matlab 