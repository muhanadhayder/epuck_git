function [filtered_values]= filter_Light (values)
% Filter for Light values

%filtered_values  = filter_TP_A(values);
filtered_values  = values;