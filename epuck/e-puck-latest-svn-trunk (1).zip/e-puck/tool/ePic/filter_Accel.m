function [filtered_values]= filter_Accel (values)
% Filter for Accelerometer values

%filtered_values  = filter_TP_A(values);
filtered_values  = values;