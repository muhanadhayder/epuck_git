#include <p30f6014A.h>
#include <stdlib.h>//for random numbers
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "e_epuck_ports.h"
#include "e_init_port.h"#include "e_motors.h"#include "utility.h"#include "e_led.h"#include "e_prox.h"#include "e_ad_conv.h"#include "e_uart_char.h"#include "e_randb.h"#include "btcom.h"
#include "e_remote_control.h"
#include "e_agenda.h"

void indicateDirectionLED(double bearing);//turns on the LED corresponding to bearing bearing

int sel;//the position of the selector switch
char debugMessage[80];//this is some data to store screen-bound debug messages
int seeSomething;//boolean for forward facing prox sensors

int main(void){	myWait(500);//saftey wait period to prevent UART clogging	e_init_port();	sel = getselector();	if(sel == 0) while(1) NOP();

}
